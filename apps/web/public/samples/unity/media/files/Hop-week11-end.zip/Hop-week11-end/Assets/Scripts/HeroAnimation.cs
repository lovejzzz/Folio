using UnityEngine;

// Tells Hero's Animator what Hero is doing, so the right clip plays.
public class HeroAnimation : MonoBehaviour
{
    private Animator animator;
    private Rigidbody2D rb;
    private Transform feetCheck;

    void Start()
    {
        // Find the parts we need once, at the start.
        animator = GetComponent<Animator>();
        rb = GetComponent<Rigidbody2D>();
        feetCheck = transform.Find("FeetCheck");
    }

    void Update()
    {
        // Running means Hero is moving sideways.
        bool isRunning = Mathf.Abs(rb.linearVelocity.x) > 0.1f;

        // Use the same ground-check shape and dimensions as HeroController.
        bool isGrounded = Physics2D.OverlapBox(feetCheck.position, new Vector2(0.7f, 0.1f), 0f, LayerMask.GetMask("Ground"));

        // Hand both answers to the Animator Controller.
        animator.SetBool("isRunning", isRunning);
        animator.SetBool("isGrounded", isGrounded);
    }
}