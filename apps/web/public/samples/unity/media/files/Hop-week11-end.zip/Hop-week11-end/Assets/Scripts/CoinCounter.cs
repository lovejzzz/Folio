using UnityEngine;
using TMPro;

// Keeps the number of coins and shows it on screen.
public class CoinCounter : MonoBehaviour
{
    [SerializeField] private TMP_Text coinsText;
    private int coins = 0;

    void Start()
    {
        UpdateLabel();
    }

    // Coins call this when Hero touches them.
    public void AddCoin()
    {
        coins = coins + 1;
        UpdateLabel();
    }

    void UpdateLabel()
    {
        coinsText.text = "Coins: " + coins;
    }
}