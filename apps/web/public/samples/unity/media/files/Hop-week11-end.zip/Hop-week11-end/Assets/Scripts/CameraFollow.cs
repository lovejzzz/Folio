using UnityEngine;

// Slides the camera toward the player after the player has moved.
public class CameraFollow : MonoBehaviour
{
    [SerializeField] private Transform target;
    [SerializeField] private float smoothTime = 0.15f;
    private Vector3 velocity;

    void LateUpdate()
    {
        // Aim for the target's x and y, but keep the camera's own z.
        Vector3 goal = new Vector3(target.position.x, target.position.y, transform.position.z);
        transform.position = Vector3.SmoothDamp(transform.position, goal, ref velocity, smoothTime);
    }
}