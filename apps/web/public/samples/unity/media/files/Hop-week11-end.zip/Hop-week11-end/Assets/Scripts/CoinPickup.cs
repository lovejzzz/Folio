using UnityEngine;

// Sits on every coin. When Hero touches it, count it and remove it.
public class CoinPickup : MonoBehaviour
{
    private CoinCounter counter;

    void Start()
    {
        counter = FindAnyObjectByType<CoinCounter>();
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            counter.AddCoin();
            Destroy(gameObject);
        }
    }
}