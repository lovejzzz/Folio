using UnityEngine;

public class Spinner : MonoBehaviour
{
    // How fast the cube turns, in degrees per second.
    public float speed = 90f;

    // True means spin, false means stay still.
    public bool isSpinning = true;

    // The text that Start writes to the Console.
    public string message = "Spinner started on ";

    // Start runs once, the moment Play begins.
    void Start()
    {
        Debug.Log(message + gameObject.name);
    }

    // Update runs once every frame while Play is on.
    void Update()
    {
        if (isSpinning)
        {
            transform.Rotate(0f, speed * Time.deltaTime, 0f);
        }
    }
}
