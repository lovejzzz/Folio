using UnityEngine;

public class CameraFollow : MonoBehaviour
{
    // The object to follow. You will drag the Ball into this slot.
    public Transform target;

    // How far from the target the camera sits: same x, 6 up, 9 back.
    public Vector3 offset = new Vector3(0f, 6f, -9f);

    // LateUpdate runs after every Update, so the Ball has already moved.
    void LateUpdate()
    {
        // If no target is set yet, do nothing.
        if (target == null)
        {
            return;
        }

        transform.position = target.position + offset;
    }
}