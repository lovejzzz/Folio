using UnityEngine;

public class Rotator : MonoBehaviour
{
    // How fast the object turns, in degrees per second around x, y and z
    public Vector3 spin = new Vector3(45, 90, 45);

    void Update()
    {
        // Turn a little each frame. Time.deltaTime keeps the speed the same on every computer.
        transform.Rotate(spin * Time.deltaTime);
    }
}