using UnityEngine;
using UnityEngine.InputSystem;

public class QuitOnEscape : MonoBehaviour
{
    // Update runs once every frame
    void Update()
    {
        // Keyboard.current is empty when no keyboard is connected, so check it first
        if (Keyboard.current != null && Keyboard.current.escapeKey.wasPressedThisFrame)
        {
            // Closes a built game. In the Editor this line does nothing.
            Application.Quit();
        }
    }
}
