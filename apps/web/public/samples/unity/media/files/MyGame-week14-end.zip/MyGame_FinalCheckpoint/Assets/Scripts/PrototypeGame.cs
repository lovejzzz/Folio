using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.SceneManagement;
using TMPro;

// Keeps the score, decides when the round is won or lost, and restarts it.
public class PrototypeGame : MonoBehaviour
{
    [SerializeField] private TMP_Text statusText;
    [SerializeField] private Transform player;
    [SerializeField] private int pickupsToWin = 5;
    [SerializeField] private float leaveLimit = 20f;

    private int score;
    private bool roundOver;

    // Other scripts read this to stop moving when the round is over.
    public bool RoundOver => roundOver;

    void Start()
    {
        Refresh();
    }

    void Update()
    {
        // R restarts at any moment: during the round or after it ends.
        if (Keyboard.current != null && Keyboard.current.rKey.wasPressedThisFrame)
        {
            SceneManager.LoadScene(SceneManager.GetActiveScene().name);
        }

        // Safety net: if the player gets too far from the middle, the round is lost.
        if (!roundOver && player != null)
        {
            float distance = Vector3.Distance(player.position, Vector3.zero);
            if (distance > leaveLimit)
            {
                Lose("You left the level.");
            }
        }
    }

    // Called by the player each time it touches a pickup.
    public void AddPoint()
    {
        if (roundOver) return;
        score++;
        if (score >= pickupsToWin)
        {
            Finish("You win! Press R to play again.");
        }
        else
        {
            Refresh();
        }
    }

    // Called by the player when it touches a hazard, and by Update when it leaves the level.
    public void Lose(string reason)
    {
        if (roundOver) return;
        Finish(reason + " Press R to try again.");
    }

    private void Finish(string message)
    {
        roundOver = true;
        statusText.text = message;
    }

    private void Refresh()
    {
        statusText.text = "Score: " + score + " / " + pickupsToWin;
    }
}
