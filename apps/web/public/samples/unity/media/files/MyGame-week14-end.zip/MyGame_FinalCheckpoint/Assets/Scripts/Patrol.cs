using UnityEngine;

// Slides an object back and forth along a line, like a guard walking a path.
public class Patrol : MonoBehaviour
{
    [SerializeField] private Vector3 direction = Vector3.right;
    [SerializeField] private float distance = 4f;
    [SerializeField] private float speed = 2f;

    private Vector3 startPosition;

    void Start()
    {
        startPosition = transform.position;
    }

    void Update()
    {
        // PingPong counts up to twice the distance and back down again.
        float offset = Mathf.PingPong(Time.time * speed, distance * 2f) - distance;
        transform.position = startPosition + direction * offset;
    }
}
