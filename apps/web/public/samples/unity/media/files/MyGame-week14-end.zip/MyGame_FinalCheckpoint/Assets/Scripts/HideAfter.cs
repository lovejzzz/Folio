using UnityEngine;

// Hides this object a few seconds after the game starts.
public class HideAfter : MonoBehaviour
{
    // How long the object stays visible, in seconds.
    [SerializeField] float seconds = 8f;

    void Start()
    {
        // Call Hide once, after the wait.
        Invoke(nameof(Hide), seconds);
    }

    void Hide()
    {
        // Turn the object off. It is hidden, not destroyed.
        gameObject.SetActive(false);
    }
}
