using UnityEngine;
using UnityEngine.InputSystem;

// Moves the capsule with A, W, S and D and reacts to pickups and the hazard.
public class Player3D : MonoBehaviour
{
    [SerializeField] private PrototypeGame game;
    [SerializeField] private float speed = 6f;

    private Rigidbody rb;
    private Vector2 input;

    void Start()
    {
        rb = GetComponent<Rigidbody>();
    }

    // Read the keys once per frame.
    void Update()
    {
        Keyboard keyboard = Keyboard.current;
        if (keyboard == null) return;

        float x = 0f;
        float z = 0f;
        if (keyboard.aKey.isPressed) x -= 1f;
        if (keyboard.dKey.isPressed) x += 1f;
        if (keyboard.sKey.isPressed) z -= 1f;
        if (keyboard.wKey.isPressed) z += 1f;
        input = new Vector2(x, z).normalized;
    }

    // Move the body in the physics step.
    void FixedUpdate()
    {
        if (game.RoundOver)
        {
            rb.linearVelocity = new Vector3(0f, rb.linearVelocity.y, 0f);
            return;
        }
        rb.linearVelocity = new Vector3(input.x * speed, rb.linearVelocity.y, input.y * speed);
    }

    void OnTriggerEnter(Collider other)
    {
        if (game.RoundOver) return;

        if (other.CompareTag("Pickup"))
        {
            Destroy(other.gameObject);
            game.AddPoint();
        }
        else if (other.CompareTag("Hazard"))
        {
            game.Lose("The hazard got you.");
        }
    }
}
