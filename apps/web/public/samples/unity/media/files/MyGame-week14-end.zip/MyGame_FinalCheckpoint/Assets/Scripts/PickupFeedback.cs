using UnityEngine;

// Plays a sound and a burst of particles when the player touches a Pickup.
// It sits on the Player and leaves the scoring to PrototypeGame.
public class PickupFeedback : MonoBehaviour
{
    [SerializeField] AudioSource audioSource;   // plays the sound
    [SerializeField] AudioClip pickupSound;     // the sound to play
    [SerializeField] ParticleSystem burst;      // the sparks

    // Used by the 3D route.
    void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Pickup"))
        {
            Celebrate(other.transform.position);
        }
    }

    // Used by the 2D routes.
    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Pickup"))
        {
            Celebrate(other.transform.position);
        }
    }

    void Celebrate(Vector3 where)
    {
        // Play the sound once, without cutting off any other sound.
        audioSource.PlayOneShot(pickupSound);

        // Move the sparks to the pickup, then play them.
        burst.Stop(true, ParticleSystemStopBehavior.StopEmittingAndClear);
        burst.transform.position = where;
        burst.Play();
    }
}
