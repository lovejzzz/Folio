using UnityEngine;
using UnityEngine.InputSystem;

// Runs left and right with A and D, jumps with Space, and reacts to pickups and the hazard.
public class PlayerPlatformer : MonoBehaviour
{
    [SerializeField] private PrototypeGame game;
    [SerializeField] private Transform groundCheck;
    [SerializeField] private float speed = 5f;
    [SerializeField] private float jumpForce = 7f;

    private Rigidbody2D rb;
    private float moveX;
    private bool jumpRequested;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
    }

    // Read the keys once per frame.
    void Update()
    {
        Keyboard keyboard = Keyboard.current;
        if (keyboard == null) return;

        moveX = 0f;
        if (keyboard.aKey.isPressed) moveX -= 1f;
        if (keyboard.dKey.isPressed) moveX += 1f;

        // A key press lasts one frame, so remember it until the physics step.
        if (keyboard.spaceKey.wasPressedThisFrame) jumpRequested = true;
    }

    // Move the body in the physics step.
    void FixedUpdate()
    {
        if (game.RoundOver)
        {
            rb.linearVelocity = new Vector2(0f, rb.linearVelocity.y);
            jumpRequested = false;
            return;
        }

        rb.linearVelocity = new Vector2(moveX * speed, rb.linearVelocity.y);

        if (jumpRequested && IsGrounded())
        {
            rb.AddForce(Vector2.up * jumpForce, ForceMode2D.Impulse);
        }
        jumpRequested = false;
    }

    // True when a small circle at the feet touches something on the Ground layer.
    private bool IsGrounded()
    {
        return Physics2D.OverlapCircle(groundCheck.position, 0.2f, LayerMask.GetMask("Ground")) != null;
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        if (game.RoundOver) return;

        if (other.CompareTag("Pickup"))
        {
            Destroy(other.gameObject);
            game.AddPoint();
        }
        else if (other.CompareTag("Hazard"))
        {
            game.Lose("The hazard got you.");
        }
    }
}
