using UnityEngine;
using UnityEngine.InputSystem;

// Moves a circle in four directions with A, W, S and D and reacts to pickups and the hazard.
public class PlayerTopDown : MonoBehaviour
{
    [SerializeField] private PrototypeGame game;
    [SerializeField] private float speed = 5f;

    private Rigidbody2D rb;
    private Vector2 input;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
    }

    // Read the keys once per frame.
    void Update()
    {
        Keyboard keyboard = Keyboard.current;
        if (keyboard == null) return;

        float x = 0f;
        float y = 0f;
        if (keyboard.aKey.isPressed) x -= 1f;
        if (keyboard.dKey.isPressed) x += 1f;
        if (keyboard.sKey.isPressed) y -= 1f;
        if (keyboard.wKey.isPressed) y += 1f;
        input = new Vector2(x, y).normalized;
    }

    // Move the body in the physics step.
    void FixedUpdate()
    {
        if (game.RoundOver)
        {
            rb.linearVelocity = Vector2.zero;
            return;
        }
        rb.linearVelocity = input * speed;
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        if (game.RoundOver) return;

        if (other.CompareTag("Pickup"))
        {
            Destroy(other.gameObject);
            game.AddPoint();
        }
        else if (other.CompareTag("Hazard"))
        {
            game.Lose("The hazard got you.");
        }
    }
}
