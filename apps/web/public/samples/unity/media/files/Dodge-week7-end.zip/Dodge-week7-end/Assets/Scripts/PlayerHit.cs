using UnityEngine;

public class PlayerHit : MonoBehaviour
{
    // The manager that keeps the lives
    private GameManager gameManager;

    void Start()
    {
        // Find the one GameManager in the scene
        gameManager = FindAnyObjectByType<GameManager>();
    }

    // Unity calls this when this object bumps into another one
    void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.CompareTag("Hazard"))
        {
            // Tell the manager a life is gone
            gameManager.LoseLife();
            // Remove the hazard so it cannot hit again
            Destroy(collision.gameObject);
        }
    }
}