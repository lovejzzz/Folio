using UnityEngine;
using UnityEngine.SceneManagement;
using TMPro;

public class GameManager : MonoBehaviour
{
    // Lives the player starts with
    [SerializeField] private int startingLives = 3;
    // The text on screen that shows the lives
    [SerializeField] private TMP_Text livesText;
    // The panel with the Game over message and the Restart button
    [SerializeField] private GameObject gameOverPanel;


    // Lives left right now
    private int lives;
    // True once the game has ended
    private bool isGameOver;

    void Start()
    {
        // A game that ended left time frozen, so set it running again
        Time.timeScale = 1f;
        lives = startingLives;
        isGameOver = false;
        // Hide the Game over screen until it is needed
        gameOverPanel.SetActive(false);
        UpdateLivesText();
    }

    // Other scripts call this when the player is hit
    public void LoseLife()
    {
        // If the game is already over, do nothing
        if (isGameOver)
        {
            return;
        }

        lives = lives - 1;
        UpdateLivesText();

        if (lives <= 0)
        {
            GameOver();
        }
    }

    // Copies the number of lives onto the screen
    private void UpdateLivesText()
    {
        livesText.text = "Lives: " + lives;
    }

    // Ends the game: shows the Game over screen and freezes time
    private void GameOver()
    {
        isGameOver = true;
        gameOverPanel.SetActive(true);
        Time.timeScale = 0f;
    }

    // The Restart button calls this
    public void Restart()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }
}
