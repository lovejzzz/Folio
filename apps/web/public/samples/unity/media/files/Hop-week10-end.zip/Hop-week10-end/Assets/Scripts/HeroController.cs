using UnityEngine;
using UnityEngine.InputSystem;

public class HeroController : MonoBehaviour
{
    // How fast Hero runs, in units per second.
    [SerializeField] float moveSpeed = 6f;

    // How hard the jump pushes. Hero's mass is 1, so this is also the upward speed.
    [SerializeField] float jumpForce = 12f;

    // An empty object at Hero's feet that marks where to look for ground.
    [SerializeField] Transform feetCheck;

    Rigidbody2D rb;
    InputAction moveAction;
    InputAction jumpAction;
    bool jumpRequested;

    // A thin box: a little narrower than Hero, so a wall at Hero's side cannot touch it.
    Vector2 feetBoxSize = new Vector2(0.7f, 0.1f);

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        // Switch the project's input actions on. Some project templates leave them off.
        InputSystem.actions.Enable();
        moveAction = InputSystem.actions.FindAction("Move");
        jumpAction = InputSystem.actions.FindAction("Jump");

        // Zero friction, so Hero never sticks to the side of a platform.
        rb.sharedMaterial = new PhysicsMaterial2D { friction = 0f };
    }

    void Update()
    {
        // Update sees every key press, so remember it until the next physics step.
        if (jumpAction.WasPressedThisFrame())
        {
            jumpRequested = true;
        }
    }

    void FixedUpdate()
    {
        float x = moveAction.ReadValue<Vector2>().x;
        rb.linearVelocity = new Vector2(x * moveSpeed, rb.linearVelocity.y);

        if (jumpRequested && IsGrounded())
        {
            // Clear any downward speed first, then push up.
            rb.linearVelocity = new Vector2(rb.linearVelocity.x, 0f);
            rb.AddForce(Vector2.up * jumpForce, ForceMode2D.Impulse);
        }

        // Forget the request, whether or not Hero could jump.
        jumpRequested = false;
    }

    bool IsGrounded()
    {
        // Is anything on the Ground layer inside the feet box?
        Collider2D ground = Physics2D.OverlapBox(feetCheck.position, feetBoxSize, 0f, LayerMask.GetMask("Ground"));
        return ground != null;
    }

    // Draws the feet box in the Scene view when Hero is selected.
    void OnDrawGizmosSelected()
    {
        if (feetCheck == null) return;
        Gizmos.DrawWireCube(feetCheck.position, feetBoxSize);
    }
}