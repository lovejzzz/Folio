using UnityEngine;
using UnityEngine.InputSystem;   // lets us read the keyboard

public class SlowFocus : MonoBehaviour
{
    [SerializeField] float slowScale = 0.5f;   // how fast time runs while Shift is held

    void Update()
    {
        if (Time.timeScale == 0f) return;   // time is stopped (game over), so leave it alone

        bool held = Keyboard.current != null && Keyboard.current.leftShiftKey.isPressed;   // false if no keyboard is available
        Time.timeScale = held ? slowScale : 1f;                // half speed if held, else normal
    }

    void OnDestroy()
    {
        Time.timeScale = 1f;   // put time back to normal when this object goes away
    }
}