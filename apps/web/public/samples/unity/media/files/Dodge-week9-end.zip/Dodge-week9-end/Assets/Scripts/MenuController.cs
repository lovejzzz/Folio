using UnityEngine;
using UnityEngine.SceneManagement;   // lets us load scenes

public class MenuController : MonoBehaviour
{
    [SerializeField] string gameSceneName = "SampleScene";   // the scene Play loads

    public void PlayGame()
    {
        Time.timeScale = 1f;                     // make sure time runs at normal speed
        SceneManager.LoadScene(gameSceneName);   // load the Dodge scene by name
    }

    public void QuitGame()
    {
        Debug.Log("Quit pressed");   // shows in the Console, so you can see the button works
        Application.Quit();          // closes a build; does nothing in the Editor
    }
}