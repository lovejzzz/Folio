using UnityEngine;
using UnityEngine.InputSystem;

public class PlayerMover : MonoBehaviour
{
    // How fast the Player moves, in units per second
    [SerializeField] private float speed = 6f;

    private Rigidbody rb;
    private Vector2 moveInput;

    void Start()
    {
        // Find the Rigidbody on this same object once, at the start
        rb = GetComponent<Rigidbody>();
    }

    void Update()
    {
        // Read the keyboard every frame: x is left and right, y is forward and back
        float x = 0f;
        float y = 0f;

        if (Keyboard.current.aKey.isPressed || Keyboard.current.leftArrowKey.isPressed) x -= 1f;
        if (Keyboard.current.dKey.isPressed || Keyboard.current.rightArrowKey.isPressed) x += 1f;
        if (Keyboard.current.sKey.isPressed || Keyboard.current.downArrowKey.isPressed) y -= 1f;
        if (Keyboard.current.wKey.isPressed || Keyboard.current.upArrowKey.isPressed) y += 1f;

        moveInput = new Vector2(x, y);
    }

    void FixedUpdate()
    {
        // Set the sideways speed, keep the falling speed that gravity gives
        rb.linearVelocity = new Vector3(moveInput.x * speed, rb.linearVelocity.y, moveInput.y * speed);
    }
}