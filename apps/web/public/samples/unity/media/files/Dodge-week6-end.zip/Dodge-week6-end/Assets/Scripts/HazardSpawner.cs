using UnityEngine;

public class HazardSpawner : MonoBehaviour
{
    // The prefab to copy. You drag it in from the Project window.
    [SerializeField] private GameObject hazardPrefab;

    // Seconds to wait before the next hazard. It shrinks as the game goes on.
    public float interval = 2f;

    // The interval never goes below this
    [SerializeField] private float minInterval = 0.4f;

    // After each spawn, interval is multiplied by this (0.95 is 5 percent shorter)
    [SerializeField] private float speedUp = 0.95f;

    // Hazards appear between -areaHalfWidth and +areaHalfWidth on x and z
    [SerializeField] private float areaHalfWidth = 6f;

    // How high above the Floor hazards appear
    [SerializeField] private float spawnHeight = 8f;

    // Seconds counted since the last spawn
    private float timer = 0f;

    void Update()
    {
        // Add the seconds the last frame took
        timer += Time.deltaTime;

        if (timer >= interval)
        {
            timer = 0f;
            Spawn();

            // Shorter wait next time, but never below minInterval
            interval = Mathf.Max(interval * speedUp, minInterval);
        }
    }

    void Spawn()
    {
        // A random spot on the Floor, high above it
        float x = Random.Range(-areaHalfWidth, areaHalfWidth);
        float z = Random.Range(-areaHalfWidth, areaHalfWidth);
        Vector3 position = new Vector3(x, spawnHeight, z);

        // Make one copy of the prefab, with no turn
        Instantiate(hazardPrefab, position, Quaternion.identity);
    }
}