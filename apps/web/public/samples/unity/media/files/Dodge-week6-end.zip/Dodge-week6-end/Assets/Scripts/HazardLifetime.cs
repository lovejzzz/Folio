using UnityEngine;

public class HazardLifetime : MonoBehaviour
{
    // Seconds the hazard lives before it removes itself
    [SerializeField] private float lifetime = 6f;

    void Start()
    {
        // Destroy removes this whole GameObject after the delay
        Destroy(gameObject, lifetime);
    }
}