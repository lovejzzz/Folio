using UnityEngine;
using UnityEngine.InputSystem;

public class BallController : MonoBehaviour
{
    // How hard the keys push the Ball. Change it in the Inspector.
    public float force = 10f;

    // The Ball's Rigidbody, found once in Start.
    private Rigidbody rb;

    // The direction the keys ask for, saved by Update for FixedUpdate to use.
    private Vector3 moveInput;

    void Start()
    {
        // Find the Rigidbody on this same GameObject.
        rb = GetComponent<Rigidbody>();
    }

    void Update()
    {
        Keyboard keyboard = Keyboard.current;

        // If no keyboard is available, clear the saved push direction.
        if (keyboard == null)
        {
            moveInput = Vector3.zero;
            return;
        }

        float x = 0f;
        float z = 0f;

        // isPressed is true for as long as the key is held.
        if (keyboard.dKey.isPressed) { x += 1f; }
        if (keyboard.aKey.isPressed) { x -= 1f; }
        if (keyboard.wKey.isPressed) { z += 1f; }
        if (keyboard.sKey.isPressed) { z -= 1f; }

        // normalized gives a nonzero arrow length 1 and leaves a zero arrow at 0.
        moveInput = new Vector3(x, 0f, z).normalized;
    }

    void FixedUpdate()
    {
        // Push the Ball once per physics step.
        rb.AddForce(moveInput * force);
    }
}