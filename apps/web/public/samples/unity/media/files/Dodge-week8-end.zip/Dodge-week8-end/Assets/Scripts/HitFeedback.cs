using UnityEngine;

public class HitFeedback : MonoBehaviour
{
    [SerializeField] AudioSource hitSource;   // the Audio Source that plays the sound
    [SerializeField] AudioClip hitClip;       // the recording to play
    [SerializeField] float hitVolume = 1f;    // 0 is silent, 1 is full volume
    [SerializeField] float pitchMin = 0.9f;   // lowest pitch a hit can have
    [SerializeField] float pitchMax = 1.1f;   // highest pitch a hit can have
    [SerializeField] ParticleSystem sparks;   // the burst of sparks
    [SerializeField] int sparkCount = 20;     // how many sparks a hit makes

    // PlayerHit calls this the moment a hazard touches the Player
    public void Play()
    {
        hitSource.pitch = Random.Range(pitchMin, pitchMax);   // a new pitch each hit
        hitSource.PlayOneShot(hitClip, hitVolume);
        sparks.Emit(sparkCount);                              // make the sparks now
    }
}