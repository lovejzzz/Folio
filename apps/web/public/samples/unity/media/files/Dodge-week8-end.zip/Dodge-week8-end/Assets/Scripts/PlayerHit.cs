using UnityEngine;

public class PlayerHit : MonoBehaviour
{
    HitFeedback feedback;   // the script that makes sound and sparks
    GameManager manager;    // the script that keeps the lives

    void Start()
    {
        feedback = GetComponent<HitFeedback>();
        manager = FindAnyObjectByType<GameManager>();
    }

    // Called when something solid touches the Player
    void OnCollisionEnter(Collision collision)
    {
        Hit(collision.gameObject);
    }

    // Called when the Player enters a trigger
    void OnTriggerEnter(Collider other)
    {
        Hit(other.gameObject);
    }

    void Hit(GameObject other)
    {
        if (!other.CompareTag("Hazard")) return;   // ignore the Floor and anything else
        feedback.Play();                           // feedback first
        manager.LoseLife();                        // then the life
        Destroy(other);                            // remove the hazard so it cannot hit again
    }
}